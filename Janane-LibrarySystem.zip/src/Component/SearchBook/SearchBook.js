import "./SearchBook.css";

function SearchBook() {
  return <div></div>;
}
export default SearchBook;
