import "./EditBook.css";

function EditBook() {
  return <div>Hello World</div>;
}

export default EditBook;
